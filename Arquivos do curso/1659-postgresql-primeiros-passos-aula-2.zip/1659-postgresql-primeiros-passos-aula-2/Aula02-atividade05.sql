 SELECT * 
   FROM aluno
  WHERE nome = 'Nico';

DELETE 
   FROM aluno
  WHERE nome = 'Nico';